
extern void primSafeArrayDestroy (void* p);
