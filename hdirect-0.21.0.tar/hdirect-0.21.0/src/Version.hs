--Automatically generated
module Version where

pkg_name :: String
pkg_name    = "HaskellDirect (ihc.exe)"
pkg_version :: String
pkg_version = "version 0.21"
